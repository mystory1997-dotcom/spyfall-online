package com.temgraph.spyfallonline;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.LinearLayout;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    private ProgressBar progress;
    private TextView error;
    private String baseUrl;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,14,26));
        getWindow().setNavigationBarColor(Color.rgb(8,14,26));
        baseUrl = BuildConfig.SERVER_URL.replaceAll("/+$", "");
        buildScreen();
        if (baseUrl.contains("YOUR-SERVER")) {
            showError("แอปพร้อมแล้ว แต่ยังไม่ได้ตั้งค่าเซิร์ฟเวอร์เกมออนไลน์\n\nต้องนำเซิร์ฟเวอร์ Spyfall Online ขึ้นออนไลน์ แล้วสร้าง APK ใหม่โดยใส่ URL ของเซิร์ฟเวอร์ก่อนจึงจะเล่นได้");
        } else {
            webView.loadUrl(baseUrl);
        }
    }

    private void buildScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,14,26));
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if (scheme.equals("https") && uri.getHost() != null && uri.getHost().equals(Uri.parse(baseUrl).getHost())) return false;
                return true;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError e) {
                if (request.isForMainFrame()) showError("เชื่อมต่อเซิร์ฟเวอร์เกมไม่ได้\n\nตรวจสอบอินเทอร์เน็ตหรือสถานะเซิร์ฟเวอร์ แล้วแตะเพื่อโหลดใหม่");
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, 5, Gravity.TOP);
        root.addView(progress, pp);
        error = new TextView(this);
        error.setTextColor(Color.WHITE); error.setTextSize(16); error.setGravity(Gravity.CENTER);
        error.setTypeface(Typeface.DEFAULT, Typeface.BOLD); error.setPadding(32,32,32,32);
        error.setBackgroundColor(Color.rgb(8,14,26)); error.setVisibility(View.GONE);
        error.setOnClickListener(v -> { error.setVisibility(View.GONE); webView.setVisibility(View.VISIBLE); webView.reload(); });
        root.addView(error, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    private void showError(String message) {
        if (error != null) { error.setText(message + "\n\nแตะหน้าจอเพื่อลองอีกครั้ง"); error.setVisibility(View.VISIBLE); }
        if (webView != null) webView.setVisibility(View.GONE);
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) { webView.goBack(); return true; }
        return super.onKeyDown(keyCode, event);
    }
}
